#include "Scene.h"
#include "UIManager.h"

void Scene::init() {
    UIManager::instance().init();
}
